import pygame
import time
import random
import sys
import os

play = True

# initializing pygame
pygame.init()

# establsiing the colors
black = pygame.Color(0, 0, 0)
white = pygame.Color(255, 255, 255)
red = pygame.Color(255, 0, 0)
green = pygame.Color(0, 255, 0)
blue = pygame.Color(0, 0, 255)

# difining window dimensions
window_x, window_y = 800, 450

# setting up the window
pygame.display.set_caption('box jumper')
window = pygame.display.set_mode((window_x, window_y))
background = pygame.image.load(os.path.join('background.png')).convert()
ground = pygame.image.load(os.path.join('ground (1).png')).convert()
font = pygame.font.Font(None, 25)
# establishing the fps for the window
fps = 60

# setting up the high score
High_score_file_read = open('high_score.txt', 'r')
High_score_file_write = open('high_score.txt', 'a')
#high_score = int(High_score_file_read.readline())

# establising the block and coordinates
block_x = 600
block_y_1 = 340
block_y_2 = 250
block_y = random.choice([block_y_1, block_y_2])
block = pygame.image.load(os.path.join('block.png')).convert()
block_rect = block.get_rect(topleft = (block_x, block_y))

# block # 2:
block_x_2 = 1200
block_2_y = random.choice([block_y_1, block_y_2])
block_2 = pygame.image.load(os.path.join('block.png')).convert()
block_rect_2 = block.get_rect(topleft = (block_x_2, block_2_y))


# establising the character and coordinates 
character_x = 25
character_y = 323
character_width, character_height = 45, 80
character = pygame.image.load(os.path.join('charcter_1.png'))
character_rect = character.get_rect(topleft = (character_x, character_y))
character_model_var = 0


# establishing the score keeping variable
score = 0

# establishing the gravity variable
gravity = 1


# handles when the player collides whith the block
def game_over():
	print('game ended')
	time.sleep(5)
	pygame.quit()


# the gameplay loop
while play:
	# establishing the clock
	clock = pygame.time.Clock()
	
	# event handlers
	for event in pygame.event.get():
		
		# when pygame is told to quit
		if event.type == pygame.quit:
			pygame.quit
			sys.exit()

		# keyboard button presses	
		if event.type == pygame.KEYDOWN:

			# jump is pressed
			if event.key == pygame.K_UP or event.key == pygame.K_w or event.key == pygame.K_SPACE:
				print('jump pressed')
				
				# only if the character is on the ground, it will jump by chaning the gravity to a negitive value
				if character_rect.bottom == 403:
					gravity -= 25
			
			# right is pressed
			if event.key == pygame.K_RIGHT or event.key == pygame.K_d:
				for i in range(50): character_rect.x += 1
				print('right pressed')
			
			# left is pressed
			if event.key == pygame.K_LEFT or event.key == pygame.K_a:
				for i in range(50): character_rect.x -= 1
				print('left pressed')

	# handles displaying the score
	score_display = font.render('Score: ' + str(score), True, 'black')
	# high_score_display = font.render('High Score: ' + str(high_score), True, 'black')

	# if the enemy is behind the player, the score will iterate up
	if block_rect.x <= character_rect.x:
		score = score + 1

	# if the second block is behind the player, the score will iterate up
	if block_rect_2.x <= character_rect.x:
		score = score + 1

	if block_rect.x == block_rect_2.x:
		game_over()

	# managing high score:
	"""
	if score > high_score:
		print('high score updated, ' + str(high_score))
		high_score = score
		high_score = str(high_score)
		High_score_file_write.writelines(high_score)
		high_score = int(high_score)
	"""
	# if the enemy goes off the screen, it will teleport to the right
	if block_rect.x < -225:
		block_y = random.choice([block_y_1, block_y_2])
		block_rect = block.get_rect(topleft = (block_x, block_y))
		block_rect.x = 800
	
	# if the second enemy goes off the screen, it will teleport to the right
	if block_rect_2.x < -225:
		block_y_2 = random.choice([block_y_1, block_y_2])
		block_rect_2 = block.get_rect(topleft = (block_x_2, block_y))
		block_rect_2.x = 1400

	# checks if the player is below the game, if so it will quit
	if character_y < 330:
		pygame.quit

	# if the gravity variable is less than the cap of 5, it will iterate upwards
	if gravity <= 5:
		gravity += 1
	
	# constantly pushes the player down by the number of pixels that the gravity variable states
	character_rect.y += gravity

	# establishes the floor by moving the player character to a set point if it falls below that point
	if character_rect.bottom >= 403: character_rect.bottom = 403

	# calls the game_over() function if the player and block collide
	if character_rect.colliderect(block_rect):
		game_over()

	# calls the game_over() function if the player and block collide
	if character_rect.colliderect(block_rect_2):
		game_over()

	# controls how far the blocks move
	block_move = random.randint(1, 15)

	# moves the block left by a random number of pixels between 1 and 15
	block_rect.x -= block_move
	
	# moves the second block left by a random number of pixels between 1 and 15
	block_rect_2.x -= block_move

	# handles the character's walking animation
	if character_model_var <= 10: 
		character = pygame.image.load(os.path.join('charcter_1.png'))
		character_model_var += 1
	elif character_model_var > 10 and character_model_var <= 20:
		character = character = pygame.image.load(os.path.join('charcter_2.png'))
		character_model_var += 1
	else:
		character_model_var = 0

	# draws everything to the screen
	window.fill(black)
	window.blit(background, (0, 0))
	window.blit(ground, (0, 400))
	window.blit(score_display, (10, 10))
	# window.blit(high_score_display, (10, 30))
	window.blit(block, block_rect)
	window.blit(block, block_rect_2)
	window.blit(character, character_rect)

	pygame.display.update()
	clock.tick(fps) 