import pygame
import time
import random
import sys
import os

play = True

black = pygame.Color(0, 0, 0)
white = pygame.Color(255, 255, 255)
red = pygame.Color(255, 0, 0)
green = pygame.Color(0, 255, 0)
blue = pygame.Color(0, 0, 255)
character_blue = pygame.Color(0, 0, 225)

pygame.init()

window_x, window_y = 800, 450

pygame.display.set_caption('box jumper')
window = pygame.display.set_mode((window_x, window_y))
fps = 60
background = pygame.image.load(os.path.join('background.png')).convert()
ground = pygame.image.load(os.path.join('ground (1).png')).convert()
font = pygame.font.Font(None, 25)

block_x = 600
block_y = 340
block = pygame.image.load(os.path.join('block.png')).convert()
block_rect = block.get_rect(topleft = (block_x, block_y))

#character = 
character_x = 25
character_y = 323
character_width, character_height = 45, 80
character = pygame.image.load(os.path.join('untitled.png'))
character_rect = character.get_rect(topleft = (character_x, character_y))

score = 0

gravity = 1

def game_over():
	print('game ended')
	time.sleep(5)
	pygame.quit()

jump_count = 0

while play:
	clock = pygame.time.Clock()
	for event in pygame.event.get():
		if event.type == pygame.quit:
			pygame.quit()
			sys.exit()
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_UP or event.key == pygame.K_w or event.key == pygame.K_SPACE:
				print('jump pressed')
				if character_rect.bottom == 403:
					gravity -= 25
			if event.key == pygame.K_RIGHT or event.key == pygame.K_d:
				for i in range(50): character_rect.x += 1
				print('right pressed')
			if event.key == pygame.K_LEFT or event.key == pygame.K_a:
				for i in range(50): character_rect.x -= 1
				print('left pressed')


	score_display = font.render('Score: ' + str(score), True, 'black')
	
	if block_rect.x <= character_rect.x:
		score = score + 1

	if block_rect.x < -225:
		block_rect.x = 800

	if character_y < 330:
		pygame.QUIT 

	if gravity <= 5:
		gravity += 1
	character_rect.y += gravity

	if character_rect.bottom >= 403: character_rect.bottom = 403

	if character_rect.colliderect(block_rect):
		game_over()

	block_rect.x -= random.randint(1, 15)
	window.fill(black)
	window.blit(background, (0, 0))
	window.blit(ground, (0, 400))
	window.blit(score_display, (10, 10))
	window.blit(block, block_rect)
	window.blit(character, character_rect)

	pygame.display.update()
	clock.tick(fps) 